<?php

include 'classes/admin_class.php';
$admin = new admin();
echo $eg = $admin->calcEGFR("Male", 1.23, "30");
echo $admin->deriveClinicalImpressionFromEGFR($eg);
?>
