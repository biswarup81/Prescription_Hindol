<!--BEGIN header-->
    <div id="header">
    
    	<!--BEGIN logo-->
        <div id="logo">        
        	<div class="black">
            <img src="images/logo.png" style="padding-bottom:8px; " /><br/>
            MBBS, MHSc(Diabetology), MRCP<br>
			Fellowship in Pulmonology (ACCP).<br>
			Post Graduate Diploma in Geriatric Medicine<br>
			PHYSICAN & SPECIALIST DIABEOLOGIST<br></div>
            <div class="gray"><b>AFFILIATIONS</b>: American Diabetes Association<br>
			European Association for Study of Diabetes<br/>
            
            </div>        
        </div>
        <!--END of logo-->
        
        <!--BEGIN info-->
   		 <div id="info">
        	<div>
            <img src="images/phone.png" align="absmiddle"/>&nbsp;&nbsp;&nbsp;<b>+91.9830047301 (M)</b><br/>
            <img src="images/email.png" align="absmiddle"/>&nbsp;&nbsp;&nbsp;<b>soumyacv.koldiab@gmail.com</b><br/>
            
            </div>
        
        </div>
        <!--END of info-->
    
    
    </div>
    <!--END of header-->
    
    <div class="logout"><a href="visit_list.php" class="vlink">VISIT LIST</a> &nbsp; &nbsp; &nbsp;
        <a href="master.php" class="vlink">Master Data Management</a> &nbsp; &nbsp; &nbsp;
        <a href="reports.php" class="vlink">Reports</a> &nbsp; &nbsp; &nbsp;
        <a href="logout.php" class="vlink">Logout</a></div>
<!--END of header-->