<?php ob_start() ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>:: Dr. Soumyabrata Roy Choudhuri :: Prescription Management :: Login</title>
<link rel="stylesheet" type="text/css" href="style.css" />
<link rel="stylesheet" type="text/css" href="inc/b.css" />
<link href="css/style.css" rel="stylesheet" type="text/css"/>
</head>
<?php
include "datacon.php";

$err = false;
$print = "";
if(isset($_REQUEST['action'])){
    $action=$_REQUEST['action'];
    if($action=='login'){


        $uname=stripslashes(trim($_POST['user_name']));
        $pass=stripslashes($_POST['password']);

        $sql = "select * from user where user_name = '$uname' and user_password = '$pass'";
        $r = mysql_query($sql) or die(mysql_error());
        $d = mysql_fetch_object($r) ;

        
        if(mysql_num_rows($r) > 0){
            $user_type = $d->label;
            $user_name = $d->user_name;
            $_SESSION['user_name'] = $user_name;
            $_SESSION['user_type'] = $user_type;
            
            if($user_type == 'DOCTOR'){
                    echo "<script>location.href='visit_list.php'</script>";
            } else if ($user_type == 'RECEPTIONIST'){
                    echo "<script>location.href='index.php'</script>";
            }
        } else{
        $print="<font color='red'>Invalid User Name or Password</font>";

        }
    }
} 
?>

<body>
    
    <div id="wrapper">
            
            <div class="container">
        
            
<!--BEGIN header-->
    <div id="header">
    
    	<!--BEGIN logo-->
        <div id="logo">        
        	<div class="black">
            <img src="images/logo.png" style="padding-bottom:8px; " /><br/>
            MBBS, MHSc(Diabetology), MRCP<br>
			Fellowship in Pulmonology (ACCP).<br>
			Post Graduate Diploma in Geriatric Medicine<br>
			PHYSICAN & SPECIALIST DIABEOLOGIST<br></div>
            <div class="gray"><b>AFFILIATIONS</b>: American Diabetes Association<br>
			European Association for Study of Diabetes<br/>
            
            </div>        
        </div>
        <!--END of logo-->
        
        <!--BEGIN info-->
   		 <div id="info">
        	<div>
            <img src="images/phone.png" align="absmiddle"/>&nbsp;&nbsp;&nbsp;<b>+91.9830047301 (M)</b><br/>
            <img src="images/email.png" align="absmiddle"/>&nbsp;&nbsp;&nbsp;<b>soumyacv.koldiab@gmail.com</b><br/>
            
            </div>
        
        </div>
        <!--END of info-->
    
    
    </div>
    <!--END of header-->
<div id="wrapper">
    <div class="container" align="center">  
        <div class="worning" style="text-align: center;"><?php echo $print;?></div>
           
           <div class="login">
               
		<form action="index_login.php?action=login" method="post">
			<table width="350" border="0" cellspacing="4" cellpadding="5" align="center">
			  <tr>
				<td>User Name :</td>
				<td><input type="text" name="user_name" class="text" /></td>
			  </tr>
			  <tr>
				<td>Password</td>
				<td><input type="password" name="password" class="text" /></td>
			  </tr>
			  <tr>
				<td>&nbsp;</td>
				<td><input type="submit" name="login" value="Login"  
                                           style="border:solid 1px #CCCCCC; padding:3px; cursor:pointer;"/></td>
			  </tr>
			</table>
		</form>
		</div>     
    </div>
</div>
            
            <?php include("footer.php"); ?>
            
            </div>
    </div>

</body>
</html>
<?phpob_flush() ?>
