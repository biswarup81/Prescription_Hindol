<div class="block_addiction" id="others" title="Others"
        style="margin-left: 11px;">
    <div class="headings"><img src="images/Briefcase-Medical.png" />Others </div>
    <div class="inner_addiction">

    <!-- Get In Touch Starts -->
    
    <table >
        <tr>
            <td><strong>Addictions</strong></td> 
        </tr>
        <tr>
            <td><input type="checkbox" name="addictions" value="Nicotine">&nbsp;Nicotine</td> 
        </tr>
        <tr>
            <td><input type="checkbox" name="addictions" value="Alcohol">&nbsp;Alcohol</td> 
        </tr
        <tr>
            <td>&nbsp;</td> 
        </tr>
        <tr>
            <td><strong>Diabetic history</strong></td> 
        </tr>
        
        <tr>
            <td><input type="checkbox" name="family" value="Father">&nbsp;Father</td> 
        </tr>
        <tr>
            <td><input type="checkbox" name="family" value="Mother">&nbsp;Mother</td> 
        </tr>

    </table>
    



<!-- Get In Touch Ends -->					
    </div>


</div>