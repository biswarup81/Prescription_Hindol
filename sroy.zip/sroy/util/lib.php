<link rel="stylesheet" type="text/css" href="inc/b.css" />
<link href="css/style.css" rel="stylesheet" type="text/css" />
<link rel="stylesheet" href="jquery/themes/base/jquery.ui.all.css" />
<script src="jquery/jquery-1.7.2.js"></script>
<script src="jquery/ui/jquery.ui.core.js"></script>
<script src="jquery/ui/jquery.ui.widget.js"></script>
<script src="jquery/ui/jquery.ui.datepicker.js"></script>

	
<script src="jquery/external/jquery.bgiframe-2.1.2.js"></script>

<script src="jquery/ui/jquery.ui.mouse.js"></script>
<script src="jquery/ui/jquery.ui.button.js"></script>
<script src="jquery/ui/jquery.ui.draggable.js"></script>
<script src="jquery/ui/jquery.ui.position.js"></script>
<script src="jquery/ui/jquery.ui.resizable.js"></script>
<script src="jquery/ui/jquery.ui.dialog.js"></script>
<script src="jquery/ui/jquery.effects.core.js"></script>


      
<script type='text/javascript' src='inc/jquery.autocomplete.js'></script>
<link rel="stylesheet" type="text/css" href="inc/jquery.autocomplete.css" />

<script type="text/javascript" src="js/sprinkle.js"></script>
<script tyepe="text/javascript" src ="js/makeprescription.js"></script>
